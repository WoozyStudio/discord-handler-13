const Discord = require("discord.js");

module.exports = {
    name: "",
    alias: [],
    async execute(client, message, args){{
        let m = args[0]
        if(!m) return message.channel.send({ })
            if(args[0] === "") return message.channel.send({  })
    }}
}