const Discord = require("discord.js");

module.exports = {
    name: "",
    alias: [],
    async execute(client, message, args){
        
    }
}