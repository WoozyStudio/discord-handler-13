const fs = require("fs");
const allevents = [];
module.exports = async (client) => {
    try {
        try {
            console.log("They are loading the events...")
        } catch {}
        try {console.log(`Logging in to the bot...`)} catch(e) {console.log(e)}
    } catch(e){
        console.log(e)
    }
}